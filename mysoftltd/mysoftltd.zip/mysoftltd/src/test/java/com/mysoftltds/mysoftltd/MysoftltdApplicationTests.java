package com.mysoftltds.mysoftltd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MysoftltdApplicationTests {

	@Test
	void contextLoads() {
	}

}
